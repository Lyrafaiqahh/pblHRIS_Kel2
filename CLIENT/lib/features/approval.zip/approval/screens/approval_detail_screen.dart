import 'package:flutter/material.dart';
import '../controllers/approval_controllers.dart';
import 'package:provider/provider.dart';

import '../models/approval_request.dart';

class ApprovalDetailScreen extends StatefulWidget {
  final String id;

  const ApprovalDetailScreen({
    super.key,
    required this.id,
  });

  @override
  State<ApprovalDetailScreen> createState() => _ApprovalDetailScreenState();
}

class _ApprovalDetailScreenState extends State<ApprovalDetailScreen> {
  final TextEditingController noteCtl = TextEditingController();

  @override
  void dispose() {
    noteCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = Provider.of<ApprovalController>(context);
    final data = controller.getById(widget.id);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Pengajuan'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              data.name,
              style: Theme.of(context).textTheme.titleLarge,
            ),

            const SizedBox(height: 8),
            Text("NIK: ${data.nik}"),
            Text("Departemen: ${data.department}"),

            const Divider(height: 30),

            Text("Jenis Surat: ${data.letterType}"),
            Text("Diajukan: ${data.submittedAt}"),

            const SizedBox(height: 16),

            Text("Keterangan:"),
            Text(data.note),

            const Spacer(),

            // Jika status pending → tampilkan tombol ACC / Tolak
            if (data.status == ApprovalStatus.pending) ...[
              TextField(
                controller: noteCtl,
                decoration: const InputDecoration(
                  labelText: 'Catatan Admin (opsional)',
                  border: OutlineInputBorder(),
                ),
                maxLines: 2,
              ),
              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red),
                      onPressed: () async {
                        await controller.reject(data.id, noteCtl.text);
                        Navigator.pop(context);
                      },
                      child: const Text("Tolak"),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () async {
                        await controller.approve(data.id, noteCtl.text);
                        Navigator.pop(context);
                      },
                      child: const Text("ACC"),
                    ),
                  ),
                ],
              ),
            ] else ...[
              Text("Status: ${data.status.name.toUpperCase()}"),
              if (data.adminNote != null)
                Text("Catatan Admin: ${data.adminNote}")
            ]
          ],
        ),
      ),
    );
  }
}
